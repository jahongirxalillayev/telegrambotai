"""
Configuration – barcha sozlamalar .env dan o'qiladi
"""
import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()


@dataclass(frozen=True)
class Config:
    # Telegram
    TELEGRAM_TOKEN: str

    # OpenAI
    OPENAI_API_KEY: str
    OPENAI_MODEL: str
    MAX_TOKENS: int
    TEMPERATURE: float

    # Bot behaviour
    MAX_HISTORY: int          # saqlanadigan xabarlar soni (juft: user+assistant)
    RATE_LIMIT_SECONDS: float # bir foydalanuvchi uchun min interval
    MAX_MESSAGE_LENGTH: int   # Telegram max 4096

    # System prompt
    SYSTEM_PROMPT: str

    @classmethod
    def from_env(cls) -> "Config":
        token = os.getenv("TELEGRAM_TOKEN", "").strip()
        api_key = os.getenv("OPENAI_API_KEY", "").strip()

        if not token:
            raise ValueError("TELEGRAM_TOKEN .env da topilmadi!")
        if not api_key:
            raise ValueError("OPENAI_API_KEY .env da topilmadi!")

        return cls(
            TELEGRAM_TOKEN=token,
            OPENAI_API_KEY=api_key,
            OPENAI_MODEL=os.getenv("OPENAI_MODEL", "gpt-4o-mini"),
            MAX_TOKENS=int(os.getenv("MAX_TOKENS", "2048")),
            TEMPERATURE=float(os.getenv("TEMPERATURE", "0.7")),
            MAX_HISTORY=int(os.getenv("MAX_HISTORY", "20")),
            RATE_LIMIT_SECONDS=float(os.getenv("RATE_LIMIT_SECONDS", "1.0")),
            MAX_MESSAGE_LENGTH=4096,
            SYSTEM_PROMPT=os.getenv(
                "SYSTEM_PROMPT",
                (
                    "Sen kuchli universal AI assistantsan. "
                    "Aniq, foydali, professional javob ber. "
                    "Kod yozishda senior developer kabi ishlagin. "
                    "Matematika, fizika, dasturlash, biznes, tarjima, "
                    "umumiy bilim, brainstorming, analiz — hammasida yordam bera ol. "
                    "Keraksiz gapni kamaytir. Foydalanuvchi tiliga moslash."
                ),
            ),
        )


config = Config.from_env()
