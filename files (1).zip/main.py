"""
Professional Telegram AI Bot
Author: Senior Python AI Engineer
"""
import asyncio
import logging
import sys
from telegram import Update
from telegram.ext import (
    Application,
    CommandHandler,
    MessageHandler,
    filters,
    ContextTypes,
)
from config import config
from handlers import (
    start_handler,
    help_handler,
    clear_handler,
    message_handler,
)
from database import init_db

# ─────────────────────────────────────────────
# LOGGING
# ─────────────────────────────────────────────
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.StreamHandler(sys.stdout),
        logging.FileHandler("bot.log", encoding="utf-8"),
    ],
)
logger = logging.getLogger(__name__)

# Noisy libraries
logging.getLogger("httpx").setLevel(logging.WARNING)
logging.getLogger("httpcore").setLevel(logging.WARNING)
logging.getLogger("telegram").setLevel(logging.WARNING)


# ─────────────────────────────────────────────
# POST-INIT
# ─────────────────────────────────────────────
async def post_init(application: Application) -> None:
    await init_db()
    from telegram import BotCommand
    await application.bot.set_my_commands([
        BotCommand("start", "Botni boshlash"),
        BotCommand("help",  "Yordam va buyruqlar"),
        BotCommand("clear", "Suhbat tarixini tozalash"),
    ])
    logger.info("✅ Bot ishga tushdi | @%s", (await application.bot.get_me()).username)


# ─────────────────────────────────────────────
# MAIN
# ─────────────────────────────────────────────
def main() -> None:
    logger.info("🚀 Bot ishga tushmoqda...")

    app = (
        Application.builder()
        .token(config.TELEGRAM_TOKEN)
        .post_init(post_init)
        .concurrent_updates(True)
        .build()
    )

    # Command handlers
    app.add_handler(CommandHandler("start", start_handler))
    app.add_handler(CommandHandler("help",  help_handler))
    app.add_handler(CommandHandler("clear", clear_handler))

    # Message handler
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, message_handler))
    app.add_handler(MessageHandler(filters.PHOTO, message_handler))

    # Error handler
    app.add_error_handler(error_handler)

    logger.info("📡 Polling boshlandi...")
    app.run_polling(
        allowed_updates=Update.ALL_TYPES,
        drop_pending_updates=True,
    )


async def error_handler(update: object, context: ContextTypes.DEFAULT_TYPE) -> None:
    logger.error("Update %s xatolik chiqardi: %s", update, context.error, exc_info=True)


if __name__ == "__main__":
    main()
