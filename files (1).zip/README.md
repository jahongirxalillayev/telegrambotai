# 🤖 Professional Telegram AI Bot

GPT-4o-mini asosida ishlaydi | SQLite xotira | Production-ready

## Imkoniyatlar
- ✅ Har qanday savolga javob
- 💻 Kod yozish va debug
- 🔢 Matematika va fizika
- 📝 Tarjima, esse, tahlil
- 🧠 SQLite chat history (oxirgi 20 xabar)
- 🌐 O'zbek / Rus / Ingliz tillari
- ⚡ Rate limit himoya
- 📡 Typing animatsiya
- 🔁 Retry (rate limit bo'lsa avtomatik qayta urinadi)

## Ishga tushirish

```bash
# 1. Papkaga kiring
cd telegram_bot

# 2. Virtual muhit yarating
python -m venv venv
source venv/bin/activate      # Linux/Mac
venv\Scripts\activate         # Windows

# 3. Kutubxonalarni o'rnating
pip install -r requirements.txt

# 4. .env faylini tekshiring (token va key to'g'ri ekanini)
cat .env

# 5. Botni ishga tushiring
python main.py
```

## Docker bilan ishga tushirish

```bash
docker build -t telegram-ai-bot .
docker run --env-file .env telegram-ai-bot
```

## Railway Deploy

1. Barcha fayllarni GitHub repoga yuklang
2. Railway.app da GitHub reponi ulang
3. **Variables** bo'limiga `.env` dagi kalitlarni qo'shing
4. Deploy qiling — `Procfile` avtomatik ishlatiladi

## Buyruqlar

| Buyruq | Tavsif |
|--------|--------|
| /start | Botni boshlash |
| /help  | Yordam |
| /clear | Suhbat tarixini tozalash |

## Fayl tuzilmasi

```
telegram_bot/
├── main.py          # Entry point
├── config.py        # Sozlamalar (.env dan)
├── handlers.py      # Telegram handlerlar
├── ai_client.py     # OpenAI wrapper
├── database.py      # SQLite async
├── requirements.txt
├── Procfile         # Railway uchun
├── Dockerfile       # Docker uchun
├── .env             # API kalitlar (gitga yuklamang!)
└── .env.example     # Namuna
```
