"""
OpenAI async client – rate limit + retry bilan
"""
import asyncio
import logging
from typing import List, Dict, Optional
from openai import AsyncOpenAI, RateLimitError, APIError
from config import config

logger = logging.getLogger(__name__)

_client = AsyncOpenAI(api_key=config.OPENAI_API_KEY)

MAX_RETRIES = 3
RETRY_DELAY = 5  # soniya


async def chat_completion(
    messages: List[Dict[str, str]],
    system_prompt: Optional[str] = None,
) -> str:
    """
    OpenAI Chat Completion so'rovi.
    Rate limit va API xatoliklarini avtomatik qayta urinish bilan hal qiladi.
    """
    full_messages = [
        {"role": "system", "content": system_prompt or config.SYSTEM_PROMPT}
    ] + messages

    for attempt in range(1, MAX_RETRIES + 1):
        try:
            response = await _client.chat.completions.create(
                model=config.OPENAI_MODEL,
                messages=full_messages,
                max_tokens=config.MAX_TOKENS,
                temperature=config.TEMPERATURE,
            )
            text = response.choices[0].message.content or ""
            logger.info(
                "OpenAI | model=%s | tokens=%s",
                config.OPENAI_MODEL,
                response.usage.total_tokens if response.usage else "?",
            )
            return text.strip()

        except RateLimitError as e:
            wait = RETRY_DELAY * attempt
            logger.warning("Rate limit! %d-urinish. %ds kutilmoqda... (%s)", attempt, wait, e)
            if attempt < MAX_RETRIES:
                await asyncio.sleep(wait)
            else:
                return (
                    "⚠️ AI xizmat hozir band. Bir daqiqadan keyin qayta urinib ko'ring."
                )

        except APIError as e:
            logger.error("OpenAI API xatosi: %s", e)
            return f"❌ AI xatosi: {e.message}"

        except Exception as e:
            logger.exception("Kutilmagan xato: %s", e)
            return "❌ Kutilmagan xatolik yuz berdi. Qayta urinib ko'ring."

    return "❌ So'rovni bajarib bo'lmadi."
