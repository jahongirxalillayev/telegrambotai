"""
Telegram handlers – barcha buyruq va xabar ishlovchilari
"""
import asyncio
import logging
import time
from typing import Dict
from telegram import Update, Message
from telegram.constants import ChatAction
from telegram.ext import ContextTypes
from telegram.error import BadRequest

from config import config
from database import get_history, save_message, clear_history
from ai_client import chat_completion

logger = logging.getLogger(__name__)

# ─────────────────────────────────────────────
# Rate limiter (in-memory)
# ─────────────────────────────────────────────
_last_request: Dict[int, float] = {}


def _is_rate_limited(user_id: int) -> float:
    """0 qaytarsa — ruxsat. Musbat son — necha soniya kutish kerak."""
    now = time.monotonic()
    last = _last_request.get(user_id, 0.0)
    diff = now - last
    if diff < config.RATE_LIMIT_SECONDS:
        return config.RATE_LIMIT_SECONDS - diff
    _last_request[user_id] = now
    return 0.0


# ─────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────
async def _typing_action(chat_id: int, context: ContextTypes.DEFAULT_TYPE) -> None:
    """Typing animatsiyasini davom ettiradi."""
    await context.bot.send_chat_action(chat_id=chat_id, action=ChatAction.TYPING)


async def _send_long_message(message: Message, text: str) -> None:
    """4096 belgidan uzun javoblarni bo'lib yuboradi."""
    limit = config.MAX_MESSAGE_LENGTH
    if len(text) <= limit:
        await message.reply_text(text)
        return
    parts = [text[i : i + limit] for i in range(0, len(text), limit)]
    for part in parts:
        await message.reply_text(part)
        await asyncio.sleep(0.3)


# ─────────────────────────────────────────────
# /start
# ─────────────────────────────────────────────
async def start_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    name = user.first_name or "Do'stim"
    text = (
        f"👋 Salom, *{name}*!\n\n"
        "🤖 Men *Professional AI Assistant*man — GPT-4o-mini asosida.\n\n"
        "💡 *Nima qila olaman:*\n"
        "• ✅ Har qanday savolga javob beraman\n"
        "• 💻 Kod yozaman va tushuntiraman\n"
        "• 🔢 Matematik va fizika masalalarini ishlayman\n"
        "• 📝 Tarjima, esse, tahlil, xulosa yozaman\n"
        "• 🧠 Suhbat tarixini eslab qolaman\n"
        "• 🌐 O'zbek, Rus, Ingliz va boshqa tillarda gaplashaman\n\n"
        "📌 *Buyruqlar:*\n"
        "/start — Boshlash\n"
        "/help — Batafsil yordam\n"
        "/clear — Suhbat tarixini tozalash\n\n"
        "💬 Shunchaki yozing — javob beraman!"
    )
    await update.message.reply_text(text, parse_mode="Markdown")
    logger.info("User /start: %s (id=%s)", user.username or name, user.id)


# ─────────────────────────────────────────────
# /help
# ─────────────────────────────────────────────
async def help_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    text = (
        "📖 *YORDAM*\n\n"
        "*Asosiy buyruqlar:*\n"
        "• /start — Botni qayta boshlash\n"
        "• /help — Ushbu yordam xabari\n"
        "• /clear — Suhbat tarixini o'chirish\n\n"
        "*Qo'llab-quvvatlanadigan so'rovlar:*\n"
        "• Savollar va javoblar (har qanday mavzu)\n"
        "• Kod yozish va debug qilish\n"
        "• Matn tarjimasi\n"
        "• Matematik hisob-kitoblar\n"
        "• Esse va maqola yozish\n"
        "• Brainstorming va tahlil\n\n"
        "*Tillar:*\n"
        "🇺🇿 O'zbek | 🇷🇺 Rus | 🇬🇧 Ingliz | va boshqalar\n\n"
        "⚡ *Model:* GPT-4o-mini\n"
        "🧠 *Xotira:* Oxirgi 20 ta xabar saqlanadi"
    )
    await update.message.reply_text(text, parse_mode="Markdown")


# ─────────────────────────────────────────────
# /clear
# ─────────────────────────────────────────────
async def clear_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user_id = update.effective_user.id
    deleted = await clear_history(user_id)
    await update.message.reply_text(
        f"🗑️ Suhbat tarixi tozalandi! ({deleted} ta xabar o'chirildi)\n"
        "Yangi suhbat boshlashingiz mumkin."
    )
    logger.info("User %s tarixni tozaladi (%d xabar)", user_id, deleted)


# ─────────────────────────────────────────────
# Text & Photo messages
# ─────────────────────────────────────────────
async def message_handler(update: Update, context: ContextTypes.DEFAULT_TYPE) -> None:
    user = update.effective_user
    user_id = user.id
    chat_id = update.effective_chat.id

    # Rate limit tekshirish
    wait = _is_rate_limited(user_id)
    if wait > 0:
        await update.message.reply_text(
            f"⏳ Iltimos, {wait:.1f} soniya kuting..."
        )
        return

    # Foydalanuvchi xabari matnini olish
    if update.message.photo:
        user_text = update.message.caption or "Bu rasmni tahlil qil."
    else:
        user_text = (update.message.text or "").strip()

    if not user_text:
        await update.message.reply_text("💬 Iltimos, biror narsa yozing.")
        return

    logger.info("Xabar | user=%s | text=%s", user_id, user_text[:80])

    # Typing animatsiyasi
    await _typing_action(chat_id, context)

    # Tarixni DB dan olish
    history = await get_history(user_id, limit=config.MAX_HISTORY)

    # Joriy xabarni tarixga qo'shish
    history.append({"role": "user", "content": user_text})

    # Typing animatsiyasini davom ettirish (uzoq javoblar uchun)
    typing_task = asyncio.create_task(
        _keep_typing(chat_id, context)
    )

    try:
        # AI ga so'rov
        reply = await chat_completion(history)
    finally:
        typing_task.cancel()

    if not reply:
        reply = "❌ Javob olinmadi. Qayta urinib ko'ring."

    # DB ga saqlash
    await save_message(user_id, "user", user_text)
    await save_message(user_id, "assistant", reply)

    # Javobni yuborish
    await _send_long_message(update.message, reply)
    logger.info("Javob yuborildi | user=%s | uzunlik=%d", user_id, len(reply))


async def _keep_typing(chat_id: int, context: ContextTypes.DEFAULT_TYPE) -> None:
    """AI javob tayyorlayotganda typing ko'rsatib turadi."""
    try:
        while True:
            await context.bot.send_chat_action(
                chat_id=chat_id, action=ChatAction.TYPING
            )
            await asyncio.sleep(4)
    except asyncio.CancelledError:
        pass
    except Exception:
        pass
