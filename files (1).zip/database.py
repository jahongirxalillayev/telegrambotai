"""
SQLite async database – chat history saqlash
"""
import logging
from typing import List, Dict
import aiosqlite

DB_PATH = "chat_history.db"
logger = logging.getLogger(__name__)


async def init_db() -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute("""
            CREATE TABLE IF NOT EXISTS messages (
                id         INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id    INTEGER NOT NULL,
                role       TEXT    NOT NULL,   -- 'user' | 'assistant'
                content    TEXT    NOT NULL,
                created_at DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        """)
        await db.execute(
            "CREATE INDEX IF NOT EXISTS idx_user_id ON messages (user_id)"
        )
        await db.commit()
    logger.info("✅ Database tayyor: %s", DB_PATH)


async def save_message(user_id: int, role: str, content: str) -> None:
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(
            "INSERT INTO messages (user_id, role, content) VALUES (?, ?, ?)",
            (user_id, role, content),
        )
        await db.commit()


async def get_history(user_id: int, limit: int = 20) -> List[Dict[str, str]]:
    """Oxirgi `limit` ta xabarni qaytaradi (eski → yangi tartibda)."""
    async with aiosqlite.connect(DB_PATH) as db:
        async with db.execute(
            """
            SELECT role, content FROM (
                SELECT role, content, created_at
                FROM messages
                WHERE user_id = ?
                ORDER BY created_at DESC
                LIMIT ?
            ) ORDER BY created_at ASC
            """,
            (user_id, limit),
        ) as cursor:
            rows = await cursor.fetchall()
    return [{"role": r, "content": c} for r, c in rows]


async def clear_history(user_id: int) -> int:
    """Foydalanuvchi tarixini o'chiradi, o'chirilgan qatorlar sonini qaytaradi."""
    async with aiosqlite.connect(DB_PATH) as db:
        cursor = await db.execute(
            "DELETE FROM messages WHERE user_id = ?", (user_id,)
        )
        await db.commit()
        return cursor.rowcount
